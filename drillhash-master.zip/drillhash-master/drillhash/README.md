# Drillhash

Hashing algorithm for Ore cryptocurrency.
